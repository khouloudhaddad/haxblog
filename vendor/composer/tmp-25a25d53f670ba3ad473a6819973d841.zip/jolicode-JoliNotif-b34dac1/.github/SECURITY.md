# Reporting a vulnerability

If you have found any issues that might have security implications, please send a report privately to pyrech@gmail.com

Do not report security reports publicly.

